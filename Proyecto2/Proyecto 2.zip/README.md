Este proyecto consiste en una calculadora analogica que realiza las siguientes operaciones: suma, resta, ponderado, derivada, integral y logaritmo

## Herramientas Utilizadas
Para la simulación del proyecto se utilizo NI multisim

## Pasos a seguir para simular el circuito.
- Clonar el repositorio https://github.com/BerthaBrenesB/Taller_Diseno_Analogico/new/main
- Abrir NI multisim 
- Click en 'File', 'Open'
- Buscar el archivo Proyecto2/ADC.ms14 dentro del repositorio
- Seleccionar las entradas y la variable a medir
- Click en la flecha verde para correr la simulación
- En los leds de 7 segmentos se podra ver la salida correspondiente.
